﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c_sql
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static string conString = "Data Source=DESKTOP-OETKGBT;Initial Catalog=personel;Integrated Security=True";
        SqlConnection connect=new SqlConnection(conString);
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if(connect.State == ConnectionState.Closed)
                {
                    connect.Open();
                    string kayitekle = "insert into personel (adi,soyadi,) values (@kisi_adi,@kisi_soyadi)";
                    SqlCommand komut = new SqlCommand(kayitekle);
                    komut.Parameters.AddWithValue("@kisi_adi", textBox1.Text);
                    komut.Parameters.AddWithValue("@kisi_soyadi", textBox2.Text);
                    komut.ExecuteNonQuery();
                    connect.Close();
                    MessageBox.Show("işlem yapıldı");

                }
            }
            catch (Exception uyari)
            {
                MessageBox.Show("uyarınız var" + uyari);
                throw;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personelDataSet.personel' table. You can move, or remove it, as needed.
            this.personelTableAdapter.Fill(this.personelDataSet.personel);

        }
    }
}
